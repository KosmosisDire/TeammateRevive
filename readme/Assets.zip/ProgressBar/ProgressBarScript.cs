﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ProgressBarScript : MonoBehaviour
{
    private RectTransform rectTransform;
    private RectTransform barTransform;

    public int MaxWidth;
    public float Fraction;

    public float mod = 0.007f;
    public bool ShouldMock = true;

    void Awake()
    {
        this.rectTransform = GetComponent<RectTransform>();
        var bar = this.rectTransform.Find("Bar");
        bar.GetComponent<Image>().color = new Color(1, .35f, .35f);
        this.barTransform = (RectTransform)bar.transform;
    }

    // Start is called before the first frame update
    void Start()
    {
        // var boundariesTransform = (RectTransform)this.rectTransform.Find("Boundaries").transform;
        // boundariesTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, this.MaxWidth);
    }

    // Update is called once per frame
    void Update()
    {
        if (ShouldMock) {
            this.Fraction += this.mod;
            
            if (this.Fraction < 0)
            {
                this.Fraction = 0;
                this.mod = -this.mod;
            }
            else if (this.Fraction > 1)
            {
                this.Fraction = 1;
                this.mod = -this.mod;
            }
        }
        
        var delta = this.barTransform.sizeDelta;
        this.barTransform.sizeDelta = new Vector2(this.rectTransform.rect.width * Fraction, delta.y);
    }
}
