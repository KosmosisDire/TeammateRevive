using System.IO;
using UnityEditor;
using UnityEngine;

public class MoveBundlesToSolution
{
    [MenuItem("Assets/Move Asset Bundles")]
    static void BuildAllAssetBundles()
    {
        string assetBundleDirectory = "Assets/AssetBundles";
        File.Copy(Path.Combine(assetBundleDirectory, "reducehp"), Path.Combine(@"E:\Dev\github\TeammateRevive\TeammateRevive\Resources", "reducehp"), true);
        File.Copy(Path.Combine(assetBundleDirectory, "reducehp.manifest"), Path.Combine(@"E:\Dev\github\TeammateRevive\TeammateRevive\Resources", "reducehp.manifest"), true);
        Debug.Log("DONE!");
    }
}