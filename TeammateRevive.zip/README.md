# TeammateRevive - DOES NOT WORK CURRENTLY! - WIP

A simple Risk of Rain 2 mod that allows teammates to revive their fallen colleagues. But be careful, you can't fight and revive at the same time. 
