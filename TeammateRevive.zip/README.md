# Teammate Revival - DOES NOT WORK CURRENTLY! - WIP

### Allows survivors to revive their fallen colleagues. But be careful, you can't fight and revive at the same time. 

(Keywords: revival - revive - respawn - heal)

##Change Notes:

* 0.0.2
    *Fixed a few problems (still not functional yet)

* 0.0.1:
    * Fixed typos
    * updated artwork

* 0.0.0:
    * Initial "release"
